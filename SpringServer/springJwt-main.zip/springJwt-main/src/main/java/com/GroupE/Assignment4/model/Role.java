package com.GroupE.Assignment4.model;

public enum Role {
    USER,
    ADMIN,
    UNDEFINED
}
