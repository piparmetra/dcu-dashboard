package com.GroupE.Assignment4.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.GroupE.Assignment4.dto.RoomDto; 

@Service
public interface RoomService {
	
	RoomDto createRoom (RoomDto roomDto);
	
	List<RoomDto> getAllRoom();
	
	void deleteRoom(int room_id);

}
